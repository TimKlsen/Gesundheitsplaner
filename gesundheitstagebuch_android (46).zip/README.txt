# Gesundheitstagebuch für Android

## Installation
1. Die ZIP-Datei entpacken.
2. Den kompletten Ordner auf einen HTTPS-Webhost laden (z. B. einen statischen Webhost).
   Wichtig: Nicht nur `index.html`, sondern alle Dateien zusammen hochladen.
3. Die HTTPS-Adresse auf dem Android-Handy in **Google Chrome** öffnen.
4. Die Seite einmal vollständig laden, während Internet verfügbar ist.
5. In Chrome über **⋮ → App installieren** oder **Zum Startbildschirm hinzufügen** installieren.
6. Die App einmal öffnen. Danach sollte sie auch ohne Internet starten.

## Lokal gespeicherte Daten
- Die App verwendet weiterhin IndexedDB und die vorhandene Verschlüsselung.
- Die Daten bleiben im Browser-Speicher dieses Geräts und dieser Website-Adresse.
- Browserdaten/Website-Daten löschen kann auch die Tagebuchdaten löschen.
- Das verschlüsselte Backup regelmäßig exportieren und sicher aufbewahren.

## Wichtig beim Umzug
Wenn du die bisherige Datei schon benutzt und dort Daten gespeichert hast:
**Vor dem Wechsel zuerst in der bisherigen App ein Backup exportieren.**
Die Daten aus `file://` werden nicht automatisch in die neue HTTPS-Adresse übernommen.
Nach der Installation das Backup in der neuen App importieren.

## Offline-Hinweis
Die Offline-Funktion wird beim ersten Online-Aufruf eingerichtet. Die Tailwind-Datei wird zusätzlich im Service-Worker-Cache abgelegt. Für Updates muss die Website gelegentlich online aufgerufen werden.
