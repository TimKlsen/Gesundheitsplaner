/* =====================================================================
 *  vault.js – Passwortschutz und Verschlüsselung (alles lokal)
 *
 *  Ablauf, vereinfacht:
 *   1. Aus Passwort + zufälligem Salt entsteht mit PBKDF2-SHA-256
 *      (viele Wiederholungen) ein Hauptschlüssel.
 *   2. Aus dem Hauptschlüssel werden per HKDF zwei getrennte Werte
 *      abgeleitet:
 *        - "verifier": wird gespeichert und dient nur zur Prüfung,
 *                      ob das Passwort stimmt (das Passwort selbst
 *                      wird NIE gespeichert).
 *        - AES-Schlüssel: bleibt nur im Arbeitsspeicher und
 *                      verschlüsselt alle Gesundheitsdaten mit AES-256-GCM.
 *   3. Ohne das richtige Passwort sind die gespeicherten Daten
 *      nicht lesbar. Es gibt keine "Passwort vergessen"-Funktion!
 *
 *  Hinweis zu "SSH": SSH ist ein Protokoll für Fernzugriffe, nicht für
 *  Passwörter in einer App. Hier wird stattdessen der Standard
 *  SHA-256 (PBKDF2) aus dem Browser (Web Crypto API) verwendet.
 *  Es werden keine Daten über ein Netzwerk gesendet.
 * ===================================================================== */
const Vault = (() => {
  'use strict';

  const enc = new TextEncoder();
  const dec = new TextDecoder();

  // Anzahl der PBKDF2-Wiederholungen. Höher = sicherer, aber langsamer.
  // Der Wert wird pro Profil mitgespeichert, du kannst ihn also später
  // erhöhen, ohne bestehende Profile zu zerstören.
  const ITERATIONS = 250000;
  const MAX_ITERATIONS = 2000000; // Obergrenze beim Import fremder Dateien

  /** Gibt es die Verschlüsselungsfunktionen? (nur über https oder localhost) */
  function available() {
    return typeof crypto !== 'undefined' && !!crypto.subtle && !!crypto.getRandomValues;
  }

  /* ---------- Umwandlung Bytes <-> Text (Base64) ---------- */
  function toB64(buffer) {
    const bytes = new Uint8Array(buffer);
    let s = '';
    for (let i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]);
    return btoa(s);
  }
  function fromB64(str) {
    const s = atob(str);
    const out = new Uint8Array(s.length);
    for (let i = 0; i < s.length; i++) out[i] = s.charCodeAt(i);
    return out;
  }
  function randomBytes(n) {
    return crypto.getRandomValues(new Uint8Array(n));
  }

  /** Vergleich zweier Texte ohne vorzeitigen Abbruch. */
  function sameString(a, b) {
    if (a.length !== b.length) return false;
    let diff = 0;
    for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
    return diff === 0;
  }

  /**
   * Leitet aus Passwort + Salt den Prüfwert und den AES-Schlüssel ab.
   * Der AES-Schlüssel ist "nicht exportierbar": Der Browser gibt ihn
   * nicht heraus, man kann ihn nur zum Ver-/Entschlüsseln benutzen.
   */
  async function deriveKeys(password, salt, iterations) {
    const base = await crypto.subtle.importKey('raw', enc.encode(password), 'PBKDF2', false, ['deriveBits']);
    const master = await crypto.subtle.deriveBits(
      { name: 'PBKDF2', salt, iterations, hash: 'SHA-256' }, base, 256);

    const hkdf = await crypto.subtle.importKey('raw', master, 'HKDF', false, ['deriveBits', 'deriveKey']);
    const zeroSalt = new Uint8Array(32);

    const verifierBits = await crypto.subtle.deriveBits(
      { name: 'HKDF', hash: 'SHA-256', salt: zeroSalt, info: enc.encode('meine-werte/verifier') }, hkdf, 256);

    const key = await crypto.subtle.deriveKey(
      { name: 'HKDF', hash: 'SHA-256', salt: zeroSalt, info: enc.encode('meine-werte/daten') },
      hkdf, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);

    return { verifier: toB64(verifierBits), key };
  }

  /** Verschlüsselt ein Objekt (als JSON). Jedes Mal mit neuem IV. */
  async function encryptJson(key, obj) {
    const iv = randomBytes(12);
    const ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, enc.encode(JSON.stringify(obj)));
    return { iv: toB64(iv), ct: toB64(ct) };
  }

  /** Entschlüsselt. Schlägt fehl, wenn Schlüssel falsch oder Daten verändert wurden. */
  async function decryptJson(key, iv, ct) {
    const buf = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: fromB64(iv) }, key, fromB64(ct));
    return JSON.parse(dec.decode(buf));
  }

  /* ---------- Öffentliche Funktionen ---------- */

  /** Legt einen neuen, verschlüsselten Profil-Datensatz an. */
  async function createRecord(username, password, data) {
    const salt = randomBytes(16);
    const { verifier, key } = await deriveKeys(password, salt, ITERATIONS);
    const sealed = await encryptJson(key, data);
    const now = Date.now();
    const record = {
      id: Util.uid(),
      username,                 // Anmeldename (bewusst unverschlüsselt, sonst gäbe es keine Profilauswahl)
      iterations: ITERATIONS,
      salt: toB64(salt),
      verifier,
      iv: sealed.iv,
      ct: sealed.ct,            // verschlüsselte Gesundheitsdaten
      created: now,
      updated: now,
    };
    return { record, key };
  }

  /** Prüft das Passwort. Gibt true/false zurück. */
  async function verify(record, password) {
    const { verifier } = await deriveKeys(password, fromB64(record.salt), record.iterations);
    return sameString(verifier, record.verifier);
  }

  /** Entsperrt ein Profil. Wirft einen Fehler bei falschem Passwort. */
  async function unlock(record, password) {
    const { verifier, key } = await deriveKeys(password, fromB64(record.salt), record.iterations);
    if (!sameString(verifier, record.verifier)) throw new Error('Das Passwort ist falsch.');
    try {
      const data = await decryptJson(key, record.iv, record.ct);
      return { key, data };
    } catch (e) {
      throw new Error('Die Daten konnten nicht entschlüsselt werden (beschädigt?).');
    }
  }

  /** Verschlüsselt die aktuellen Daten neu und liefert den aktualisierten Datensatz. */
  async function reseal(record, key, data) {
    const sealed = await encryptJson(key, data);
    return { ...record, iv: sealed.iv, ct: sealed.ct, updated: Date.now() };
  }

  /** Neues Passwort: neues Salt, neuer Schlüssel, Daten neu verschlüsseln. */
  async function changePassword(record, newPassword, data) {
    const salt = randomBytes(16);
    const { verifier, key } = await deriveKeys(newPassword, salt, ITERATIONS);
    const sealed = await encryptJson(key, data);
    const next = {
      ...record, iterations: ITERATIONS, salt: toB64(salt), verifier,
      iv: sealed.iv, ct: sealed.ct, updated: Date.now(),
    };
    return { record: next, key };
  }

  return { available, createRecord, verify, unlock, reseal, changePassword, MAX_ITERATIONS };
})();
