/* =====================================================================
 *  util.js – kleine Hilfsfunktionen ohne Abhängigkeiten
 *  Wird als Erstes geladen; alle anderen Dateien dürfen `Util` nutzen.
 * ===================================================================== */
const Util = (() => {
  'use strict';

  const pad = (n) => String(n).padStart(2, '0');

  /**
   * Macht Text für die Ausgabe in HTML unschädlich.
   * WICHTIG: Alles, was der Nutzer eintippt (Kommentare, Namen, eigene
   * Symptome), muss vor dem Einfügen per innerHTML durch esc() laufen.
   */
  function esc(value) {
    const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
    return String(value ?? '').replace(/[&<>"']/g, (c) => map[c]);
  }

  /** Heutiges Datum als 'JJJJ-MM-TT' (lokale Zeit, nicht UTC). */
  function today() {
    const d = new Date();
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  }

  /** Datum von vor n Tagen als 'JJJJ-MM-TT'. */
  function daysAgo(n) {
    const d = new Date();
    d.setDate(d.getDate() - n);
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  }

  /** Aktuelle Uhrzeit als 'HH:MM'. */
  function nowTime() {
    const d = new Date();
    return `${pad(d.getHours())}:${pad(d.getMinutes())}`;
  }

  /** '2026-11-24' -> 'Di., 24.11.2026' */
  function formatDate(iso) {
    const [y, m, d] = String(iso).split('-').map(Number);
    return new Date(y, m - 1, d).toLocaleDateString('de-DE', {
      weekday: 'short', day: '2-digit', month: '2-digit', year: 'numeric',
    });
  }

  /** Text -> Zahl (akzeptiert Komma und Punkt). Leer/ungültig -> null. */
  function num(value) {
    if (value === null || value === undefined) return null;
    const s = String(value).trim().replace(',', '.');
    if (s === '') return null;
    const n = Number(s);
    return Number.isFinite(n) ? n : null;
  }

  /** Zahl für die Anzeige mit Komma: 75.5 -> '75,5' */
  function fmtNum(n) {
    return String(n).replace('.', ',');
  }

  /** Zufällige ID (hex) für Profile und Messungen. */
  function uid() {
    const bytes = crypto.getRandomValues(new Uint8Array(8));
    return Array.from(bytes, (b) => b.toString(16).padStart(2, '0')).join('');
  }

  /** Startet den Download einer Datei im Browser (ohne Server). */
  function download(filename, text, mime) {
    const blob = new Blob([text], { type: mime || 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  /** Erkennt den Bereich: 'ios' | 'android' | 'desktop'. */
  function detectPlatform() {
    const ua = navigator.userAgent || '';
    // iPadOS meldet sich als Mac, hat aber einen Touchscreen
    const iPadOS = navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1;
    if (/iPhone|iPad|iPod/.test(ua) || iPadOS) return 'ios';
    if (/Android/i.test(ua)) return 'android';
    return 'desktop';
  }

  /** true, wenn die App bereits als installierte App läuft. */
  function isStandalone() {
    return (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches)
      || navigator.standalone === true;
  }

  /** Dateinamen-sicherer Text. */
  function slug(text) {
    return String(text).replace(/[^\p{L}\p{N}_-]+/gu, '_').slice(0, 40) || 'profil';
  }

  return { esc, today, daysAgo, nowTime, formatDate, num, fmtNum, uid, download, detectPlatform, isStandalone, slug };
})();
